# 🔥 XYZAI - AI Coding Assistant CLI

A powerful AI coding assistant CLI with Persian/Farsi support, built with TypeScript.

## Features

- **Multiple AI Providers**: MiMo, DeepSeek, Gemini, Qwen, OpenRouter, and more
- **Free Models**: Use MiMo Auto, Gemini Flash, Llama, Mistral for free
- **Bilingual**: Persian (فارسی) and English support
- **RTL Text**: Proper right-to-left text rendering for Persian/Arabic
- **Rich Tools**: File operations, terminal commands, code search, web fetch
- **Permission System**: Configurable security with glob patterns
- **Session Management**: Save and resume conversations

## Installation

```bash
npm install -g xyzai
```

Or from source:

```bash
git clone https://github.com/xyzai/xyzai.git
cd xyzai
npm install
npm run build
npm link
```

## Usage

### Interactive Mode
```bash
xyzai
# or
xyzai chat
```

### Headless Mode
```bash
xyzai run "Write a hello world in Python"
```

### Configuration
```bash
# List models
xyzai models

# Change language
xyzai lang fa
xyzai lang en

# View config
xyzai config --list
```

## Supported Providers

| Provider | Free Models | API Key |
|----------|------------|---------|
| MiMo Auto | mimo-auto, mimo-v2.5-pro | No |
| DeepSeek | deepseek-chat, deepseek-coder | Yes |
| Gemini | gemini-2.0-flash, gemini-2.5-flash | Yes |
| Qwen | qwen-turbo, qwen-plus | Yes |
| OpenRouter | Llama 3.3, Mistral 7B | Yes |

## Commands

- `/help` - Show help
- `/model` - Change model
- `/lang` - Change language
- `/clear` - Clear conversation
- `/exit` - Exit

## Tools

- **File Read/Write/Edit**: Read and modify files
- **Bash**: Execute shell commands
- **Glob**: Find files by pattern
- **Grep**: Search file contents
- **WebFetch**: Fetch web content

## License

MIT
